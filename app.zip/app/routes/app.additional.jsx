import { useState, useEffect } from "react";
import { json } from "@remix-run/node";
import { useFetcher } from "@remix-run/react";
import { Page, Layout, Text, Card, Button, BlockStack, TextField, Modal, ProgressBar } from "@shopify/polaris";
import { TitleBar, useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { useLoaderData } from "@remix-run/react";
import { useOutletContext } from "@remix-run/react";
import db from "../db.server";
import * as XLSX from 'xlsx'; // For Excel file handling

export const loader = async ({ request }) => {
  await authenticate.admin(request);
  try {
    let history = await db.history.findFirst();
    return json(history);
  } catch (error) {
    console.error("Loader Error:", error);
    throw new Response("Unauthorized", { status: 401 }); // Return a 401 error instead of throwing an error
  }
};


// Query and Mutation to get and Post

export const action = async ({ request }) => {

  const { admin } = await authenticate.admin(request);
  const formData = new URLSearchParams(await request.text());
  const stockQuantity = Number(formData.get("stockQuantity")) || 0;
  // console.log("request---", stockQuantity);
  const sku = formData.get("sku");
  const sessionToken = formData.get("sessionToken");

  // if (!sessionToken) {
  //   throw new Response("Unauthorized", { status: 401 });
  // }
  // const isValid = validateSessionToken(sessionToken);
  // if (!isValid) {
  //   throw new Response("Invalid session token", { status: 401 });
  // }

  // Step 1: Query to get all product variants by SKU
  const productQuery = await admin.graphql(
    `#graphql
      query GetProductQuantityBySKU($sku: String) {
        products(first: 250, query: $sku) {
          edges {
            node {
              id
              title
              variants(first: 250) {
                edges {
                  node {
                    id
                    sku
                    inventoryQuantity
                  }
                }
              }
            }
          }
        }
      }`,
    {
      variables: { sku },
      headers: {
        Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
      },
    }
  );

  const productQueryResponse = await productQuery.json();
  // let successCount = 0;
  // let failureCount = 0;
  // const successItems = [];
  // const failureItems = [];
  // Check if the product exists and has variants
  if (!productQueryResponse.data || !productQueryResponse.data.products.edges.length) {
    console.error(`No product found for SKU ${sku}.`);
    // failureCount++;
    // failureItems.push({ sku });
    return json({ errors: [{ field: `${sku}`, message: "No product found for this SKU." }] });
  }

  // Step 2: Loop through all the variants and update only the one with the matching SKU
  const productVariants = productQueryResponse.data.products.edges[0].node.variants.edges;

  // Only proceed if a variant with the matching SKU is found
  const matchingVariant = productVariants.find(variant => variant.node.sku === sku);
  if (!matchingVariant) {
    console.error(`Failed to sync: No variant found with the specified SKU ${sku}`);
    // failureCount++;
    // failureItems.push({ sku });
    return json({ errors: [{ field: `${sku}`, message: "No variant found with the specified SKU." }] });

  }
  // successCount++;
  // successItems.push({ sku });
  // setSyncSummary({ successCount, failureCount, successItems, failureItems });
  // setIsSummaryPopupOpen(true);
  console.log(`Successfully found variant for SKU ${sku}. Proceeding to update inventory.`);
  const inventoryQuantity = matchingVariant.node.inventoryQuantity;
  const variantId = matchingVariant.node.id;


  // Step 3: Fetch inventory item and location data for the matching variant
  const productVariantQuery = await admin.graphql(
    `#graphql
      query getProductVariantById($variantId: ID!) {
        productVariant(id: $variantId) {
          id
          sku
          inventoryItem {
            id
            inventoryLevels(first: 250) {
              edges {
                node {
                  id
                  location {
                    id
                    name
                  }
                }
              }
            }
          }
        }
      }`,
    {
      variables: { variantId }, headers: {
        Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
      },
    }
  );

  const productVariantResponse = await productVariantQuery.json();
  const inventoryData = productVariantResponse.data.productVariant.inventoryItem.inventoryLevels.edges;

  if (inventoryData && inventoryData.length > 0) {
    const inventoryItemId = productVariantResponse.data.productVariant.inventoryItem.id;
    const locationId = inventoryData[0].node.location.id;

    // Step 4: Adjust stock for the matching variant
    const input = {
      name: "available",
      reason: "correction",
      referenceDocumentUri: "logistics://some.warehouse/take/2023-01-23T13:14:15Z",
      quantities: [
        {
          inventoryItemId: inventoryItemId,
          locationId: locationId,
          quantity: stockQuantity,
          compareQuantity: inventoryQuantity, // Use the variant's current inventory quantity
        },
      ],
    };

    const response = await admin.graphql(
      `#graphql
        mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
          inventorySetQuantities(input: $input) {
            inventoryAdjustmentGroup {
              reason
              referenceDocumentUri
              changes {
                name
                delta
                quantityAfterChange
              }
            }
            userErrors {
              code
              field
              message
            }
          }
        }`,
      {
        variables: { input }, headers: {
          Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
        },
      }
    );

    const responseJson = await response.json();

    if (responseJson.errors || responseJson.data.inventorySetQuantities.userErrors.length > 0) {
      return json({ errors: responseJson.errors || responseJson.data.inventorySetQuantities.userErrors });

    }
  }

  return json({ success: true, sku, stockQuantity, sessionToken, message: "Stock adjusted successfully." });




};


// Query and Mutation to get and Post End

export default function Index() {
  const { sessionToken } = useOutletContext();
  const history = useLoaderData();
  const [formState, setFormState] = useState(history);
  const fetcher = useFetcher();
  const shopify = useAppBridge();
  const [progress, setProgress] = useState(0); // Progress state
  const [apiProgress, setApiProgress] = useState(0); // API progress state
  const [stockQuantity, setStockQuantity] = useState(0);
  const [sku, setSku] = useState(""); // State for SKU input
  // const [file, setFile] = useState(null);
  const [syncSummary, setSyncSummary] = useState({
    successCount: 0,
    failureCount: 0,
    successItems: [],
    failureItems: [],
  });
  const [isSummaryPopupOpen, setIsSummaryPopupOpen] = useState(false);
  const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");


  console.log("sessionToken---in additional jsx ", sessionToken)


  const generateSessionId = () => {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  const [sessionId, setSessionId] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      sessionStorage.removeItem("sessionId");  // ✅ Always remove old session on reload
      const newSessionId = generateSessionId();
      sessionStorage.setItem("sessionId", newSessionId);
      setSessionId(newSessionId);
      console.log("New sessionId generated:", newSessionId);
    }
  }, []);





  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      console.log("Fetcher Data:", fetcher.data);
      const successItems = [];
      const failureItems = [];

      const { success, sku, stockQuantity, message, errors } = fetcher.data;

      if (success === true && sku && stockQuantity !== undefined) {
        setSyncSummary((prevState) => ({
          ...prevState,
          successCount: prevState.successCount + 1,
          successItems: [...prevState.successItems, { sku, stockQuantity, message }],
        }));

        successItems.push({
          sku,
          stock: stockQuantity,
          message: "Stock updated",
          status: "Success",
        });

        let logsToSave = [{ sku, stock: stockQuantity, message: "Stock updated", status: "Success" }];
        logsToSave = logsToSave.filter(log => log.sku && log.stock !== undefined);

        if (logsToSave.length > 0 && sessionId) { // ✅ Ensure sessionId is set
          fetcher.submit(
            {
              syncType: "Product Sync",
              sessionId: sessionId,
              sessionToken, // ✅ Use state sessionId
              logs: JSON.stringify(logsToSave)
            },
            {
              method: "POST", action: "/app/synclogsapi"

            }
          );
        }

        shopify.toast.show(`Stock adjusted successfully for SKU: ${sku}`);
      } else if (errors && Array.isArray(errors) && errors.length > 0) {
        const errorDetails = errors[0];
        const errorSku = errorDetails.field;

        if (errorSku) {
          setSyncSummary(prevState => ({
            ...prevState,
            failureCount: prevState.failureCount + 1,
            failureItems: [...prevState.failureItems, { sku: errorSku, message: errorDetails.message }],
          }));

          console.log("Failure:", fetcher.data.errors);
          failureItems.push({
            sku: errorSku,
            message: errorDetails.message,
            status: "Failed",
          });

          shopify.toast.show(`Error adjusting stock for SKU: ${errorSku}`);

          let logsToSave = [{ sku: errorSku, stock: stockQuantity ?? "N/A", message: errorDetails.message, status: "Failed" }];
          logsToSave = logsToSave.filter(log => log.sku && log.stock !== undefined);

          if (logsToSave.length > 0 && sessionId) {  // ✅ Ensure sessionId exists
            fetcher.submit(
              {
                syncType: "Product Sync",
                sessionId: sessionId,
                sessionToken,
                logs: JSON.stringify(logsToSave)
              },
              {
                method: "POST", action: "/app/synclogsapi"

              }
            );
          }
        }
      }
    }
  }, [fetcher.state, fetcher.data, sessionId]); // ✅ Added sessionId as a dependency
  // useEffect(() => {
  //   if (syncResults.length > 0) {
  //     syncResults.forEach(({ sku, stockQuantity }) => {
  //       // Here you can handle the results for each SKU
  //       // You can check if the SKU was successful or failed based on the fetcher.data
  //       // and update logs accordingly.
  //     });
  //   }
  // }, [syncResults]);

  const adjustStock = () => {

    fetcher.submit(
      { stockQuantity, sku, sessionToken }, // Submit both stock quantity and SKU
      {
        method: "POST",
      }

    );
    console.log("Fetcher-data:", fetcher.data)
    if (fetcher.data?.success) {
      shopify.toast.show("Stock adjusted successfully");
      console.log("Stock adjusted successfully");
    } else if (fetcher.data?.errors) {
      shopify.toast.show("Error adjusting stock.");
      console.log("Error adjusting stock.");
    }
  };

  //Stock Sync from input End

  //Stock Sync from File Upload 

  const handleFileUpload = (event) => {
    setModalMessage("Processing CSV file...");
    setIsProgressModalOpen(true);
    const selectedFile = event.target.files[0]; // Get the first file

    if (!selectedFile) {
      alert("No file selected. Please select a CSV or Excel file.");
      return;
    }

    const reader = new FileReader();

    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });

      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];

      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      console.log("Parsed Data:", jsonData);
      processCSVData(jsonData);

    };

    reader.readAsArrayBuffer(selectedFile);
  };

  const processCSVData = async (data) => {
    const validHeaders = ["SKU", "Stock"];
    const totalRows = data.length;
    setProgress(0);

    if (!data.every((row) => Object.keys(row).every((key) => validHeaders.includes(key)))) {
      shopify.toast.show("File must contain 'SKU' and 'Stock' columns.");
      return;
    }

    // let successCount = 0;
    // let failureCount = 0;
    // const successItems = [];
    // const failureItems = [];

    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

    for (let i = 0; i < totalRows; i++) {
      const row = data[i];
      const sku = row.SKU;
      const stockQuantity = Number(row.Stock);
      await delay(100);
      if (sku && !isNaN(stockQuantity)) {
        // Add a delay to prevent overwriting fetcher state too quickly

        // Submit data using fetcher
        fetcher.submit(
          { stockQuantity, sku, sessionToken },
          {
            method: "POST"
          }
        );

        // Wait for fetcher to process the response
        await new Promise(async (resolve) => {
          // Wait until fetcher.data is populated or timeout occurs
          const startTime = Date.now();
          const timeout = 3000; // Set a timeout limit (e.g., 5 seconds)

          while (true) {


            // Check for timeout after checking the response status
            if (Date.now() - startTime > timeout) {
              // console.error(`Timeout waiting for response for SKU: ${sku}`);
              // failureCount++;
              // failureItems.push({ sku, stockQuantity });
              shopify.toast.show(`3 per second adjusting stock for SKU: ${sku}`);
              resolve(); // Resolve on timeout to prevent infinite loop
              break;
            }


            // Delay for 100ms before checking again
            await new Promise((res) => setTimeout(res, 100));
          }
        });

      }

      const progressPercentage = ((i + 1) / totalRows) * 100;
      setProgress(progressPercentage);
    }



    setIsSummaryPopupOpen(true);
  };



  //Stock Sync from File Upload End


  //Sync data Api code Work Start



  // Convert XML to JSON (unchanged)
  const xmlToJson = (xml) => {
    const obj = {};

    // Check if the node is an element
    if (xml.nodeType === 1) { // Element node
      if (xml.attributes.length > 0) {
        obj["@attributes"] = {};
        for (let j = 0; j < xml.attributes.length; j++) {
          const attribute = xml.attributes.item(j);
          obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
        }
      }
    }
    // Handle text nodes
    else if (xml.nodeType === 3) { // Text node
      return xml.nodeValue.trim();
    }

    // Recursively process child nodes
    if (xml.hasChildNodes()) {
      for (let i = 0; i < xml.childNodes.length; i++) {
        const item = xml.childNodes.item(i);
        const nodeName = item.nodeName;

        if (typeof obj[nodeName] === "undefined") {
          obj[nodeName] = xmlToJson(item);
        } else {
          if (typeof obj[nodeName].push === "undefined") {
            const old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          obj[nodeName].push(xmlToJson(item));
        }
      }
    }

    return obj;
  };



  //Sync data Api code Work End

  return (
    <Page>
      <TitleBar title="Stock Adjustment" />

      <BlockStack gap="500">
        <Layout>
          {/* ✅ Single SKU Stock Update Section */}
          <Layout.Section>
            <Card gap="500">
              <BlockStack gap="200">
                <Text as="h1" variant="headingMd">
                  Update Stock by Single SKU
                </Text>
                <Text as="p" variant="bodySm" tone="subdued" >
                  Quickly update stock for a specific product by entering the SKU and the new stock quantity.
                </Text>
              </BlockStack>
              <br />
              <BlockStack gap="500">
                <TextField
                  label="Product SKU"
                  value={sku}
                  placeholder="Enter SKU (e.g., ABC123)"
                  onChange={(value) => setSku(value)}
                />
                <TextField
                  label="Stock Quantity"
                  value={stockQuantity}
                  placeholder="Enter stock amount"
                  onChange={(value) => setStockQuantity(value)}
                  type="number"
                />
                <Button variant="primary" onClick={adjustStock}>
                  Adjust Stock
                </Button>
              </BlockStack>
            </Card>
          </Layout.Section>

          {/* ✅ Bulk Stock Update Section */}
          <Layout.Section variant="oneThird">
            <BlockStack gap="500">
              <Card sectioned>
                <BlockStack gap="400">
                  <Text as="h2" variant="headingMd">
                    Update Stock via CSV or XML
                  </Text>
                  <Text as="p" variant="bodySm" tone="subdued" >
                    Upload a file to update stock in bulk. Ensure the file contains valid SKU and stock values.
                  </Text>

                  <input
                    type="file"
                    accept=".csv, .xlsx"
                    onChange={handleFileUpload}
                  />
                  {/* </BlockStack>
                  <BlockStack gap="200"> */}
                  <Text as="p" variant="bodySm" tone="subdued">
                    Supported formats: .CSV, .XLSX
                  </Text>
                </BlockStack>
              </Card>

              {/* ✅ Buttons for Progress & Summary */}
              <Button onClick={() => setIsProgressModalOpen(true)}>Check Upload Progress</Button>
              <Button onClick={() => setIsSummaryPopupOpen(true)}>View Sync Summary</Button>
            </BlockStack>
          </Layout.Section>
        </Layout>

        {/* ✅ Progress Modal */}
        <Modal
          open={isProgressModalOpen}
          onClose={() => setIsProgressModalOpen(false)}
          title="Stock Sync Progress"
          primaryAction={{
            content: "Close",
            onAction: () => setIsProgressModalOpen(false),
          }}
        >
          <Modal.Section>
            <ProgressBar progress={progress || apiProgress} />
          </Modal.Section>
        </Modal>

        {/* ✅ Sync Summary Modal */}
        <Modal
          open={isSummaryPopupOpen}
          onClose={() => setIsSummaryPopupOpen(false)}
          title="Stock Sync Summary"
          primaryAction={{
            content: "Close",
            onAction: () => setIsSummaryPopupOpen(false),
          }}
        >
          <Modal.Section>
            <Text as="h3">Sync Results</Text>
            <Text>
              ✅ <strong>Successfully Updated:</strong> {syncSummary.successCount}
            </Text>
            <Text>
              ❌ <strong>Failed Updates:</strong> {syncSummary.failureCount}
            </Text>

            {/* ✅ Display Synced Products */}
            {syncSummary.successItems.length > 0 && (
              <>
                <br />
                <Text as="h4">Updated Products:</Text>
                <BlockStack>
                  {syncSummary.successItems.map((item, index) => (
                    <Text key={index}>{`📦 SKU: ${item.sku} → Stock: ${item.stockQuantity}`}</Text>
                  ))}
                </BlockStack>
              </>
            )}

            {/* ✅ Display Failed Products */}
            {syncSummary.failureItems.length > 0 && (
              <>
                <br />
                <Text as="h4" tone="critical">Failed Products:</Text>
                <BlockStack>
                  {syncSummary.failureItems.map((item, index) => (
                    <Text key={index}>{`❌ SKU: ${item.sku} - ${item.message}`}</Text>
                  ))}
                </BlockStack>
              </>
            )}
          </Modal.Section>
        </Modal>
      </BlockStack>
    </Page>
  );

}
