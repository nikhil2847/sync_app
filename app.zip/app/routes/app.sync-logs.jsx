import { useState, useCallback } from "react";
import {
    Page, Layout, Text, Card, Button, Frame, Toast, IndexTable, Modal
} from "@shopify/polaris";
import { TitleBar } from "@shopify/app-bridge-react";
import { useLoaderData, useFetcher } from "@remix-run/react";
import db from "../db.server";
import { json } from "@remix-run/node";
import { authenticate } from "../shopify.server";

// ✅ Fetch history logs along with related LogDetail entries
export async function loader({ request }) {
    try {
        await authenticate.admin(request);
        let history = await db.history.findMany({
            orderBy: { startedAt: "desc" },
            include: { logs: true },
        });
        return json(history);
    } catch (error) {
        console.error("Loader Error:", error);
        throw new Response("Unauthorized", { status: 401 });
    }
}

// ✅ Action function for DELETE functionality
export async function action({ request }) {
    const formData = await request.formData();
    const actionType = formData.get("action");
    const ids = formData.getAll("ids").map(Number);

    try {
        if (actionType === "delete" && ids.length > 0) {
            await db.history.deleteMany({
                where: { id: { in: ids } }
            });
            return json({ success: true });
        }
    } catch (error) {
        console.error("Delete Error:", error);
        return json({ error: "Failed to delete logs" }, { status: 500 });
    }
}

export default function Index() {
    const historyData = useLoaderData();
    const fetcher = useFetcher();
   
    const [selectedIds, setSelectedIds] = useState([]);
    const [toastActive, setToastActive] = useState(false);
    const [modalActive, setModalActive] = useState(false);
    const [selectedEntry, setSelectedEntry] = useState(null);
    const [deleting, setDeleting] = useState(false);

    const toggleToast = useCallback(() => setToastActive((active) => !active), []);
    const toggleModal = useCallback(() => setModalActive((active) => !active), []);
    console.log("selectedIds", selectedIds)
    // ✅ Open Popup and Set Selected Entry
    const handleRowClick = (entry) => {
        setSelectedEntry(entry);
        setModalActive(true);
    };






    // ✅ Handle single delete
    const handleSingleDelete = (id, e) => {
        e.stopPropagation(); // Prevent modal from opening
        fetcher.submit(
            { action: "delete", ids: [id] },
        
            { method: "POST" }
        );
        toggleToast();
    };

    // ✅ Handle bulk delete
    const handleBulkDelete = () => {
        if (selectedIds.length === 0) return;

        const formData = new FormData();
        formData.append("action", "delete");
        selectedIds.forEach(id => formData.append("ids", id));

        setDeleting(true);
        fetcher.submit(formData, { method: "POST" }).then(() => {
            setDeleting(false);
            setSelectedIds([]); // Reset selection
            toggleToast();
        });
    };

    const handleSelectionChange = (selectedItems) => {
        console.log("Selection Type:", selectedItems);

        if (selectedItems === "page") {
            // Select all items on the page
            setSelectedIds(historyData.map(entry => entry.id));
        } else if (selectedItems === "none") {
            // Deselect all items
            setSelectedIds([]);
        } else if (selectedItems === "single") {
            console.warn("Unexpected selection type: single"); // Debugging
        } else if (Array.isArray(selectedItems)) {
            // Handle individual row selection
            setSelectedIds((prevSelected) => {
                let newSelection = [...prevSelected];

                selectedItems.forEach(item => {
                    if (newSelection.includes(item)) {
                        newSelection = newSelection.filter(id => id !== item); // Deselect
                    } else {
                        newSelection.push(item); // Select
                    }
                });

                return newSelection;
            });
        } else {
            console.error("Unexpected selection type:", selectedItems);
        }
    };






    console.log("selectedIds", selectedIds)

    return (
        <Frame>
            <Page>
                <TitleBar title="API Sync History" />
                <Layout>
                    <Layout.Section>
                        <Card>
                            <Text as="h2" variant="headingMd">Sync Logs</Text>
                            <br />

                            {/* ✅ Table Display */}
                            {historyData.length === 0 ? (
                                <Text>No history logs available.</Text>
                            ) : (
                                <IndexTable
                                    resourceName={{ singular: "history", plural: "histories" }}
                                    itemCount={historyData.length}
                                    headings={[
                                        { title: "No." },
                                        { title: "ID" },
                                        { title: "Post Type" },
                                        { title: "Started At" },
                                        { title: "Status" },
                                        { title: "Actions" },
                                    ]}
                                    selectedItemsCount={selectedIds.length}
                                    onSelectionChange={handleSelectionChange}
                                    selectable
                                >
                                    {historyData.map((entry, index) => (
                                        <IndexTable.Row
                                            id={entry.id}
                                            key={entry.id}
                                            selected={selectedIds.includes(entry.id)}
                                            onClick={() => {
                                                setSelectedIds((prevSelected) =>
                                                    prevSelected.includes(entry.id)
                                                        ? prevSelected.filter(id => id !== entry.id) // Deselect
                                                        : [...prevSelected, entry.id] // Select
                                                );
                                            }}
                                        >
                                            <IndexTable.Cell>{index + 1}</IndexTable.Cell>
                                            <IndexTable.Cell>{entry.id}</IndexTable.Cell>
                                            <IndexTable.Cell>{entry.postType}</IndexTable.Cell>
                                            <IndexTable.Cell>{new Date(entry.startedAt).toLocaleString()}</IndexTable.Cell>
                                            <IndexTable.Cell>{entry.status}</IndexTable.Cell>
                                            <IndexTable.Cell>
                                                <Button
                                                    plain
                                                    onClick={(e) => {
                                                        e.stopPropagation(); // Prevent row selection
                                                        setSelectedEntry(entry);
                                                        setModalActive(true);
                                                    }}
                                                >
                                                    View Logs
                                                </Button>
                                            </IndexTable.Cell>
                                        </IndexTable.Row>
                                    ))}
                                </IndexTable>

                            )}

                            <br />
                            {/* ✅ Bulk Delete Button */}
                            <Button disabled={selectedIds.length === 0 || deleting} onClick={handleBulkDelete} destructive>
                                {deleting ? "Deleting..." : "Bulk Delete Selected"}
                            </Button>
                        </Card>
                    </Layout.Section>
                </Layout>
            </Page>

            {/* ✅ Toast Notification */}
            {toastActive && <Toast content="Deleted successfully!" onDismiss={toggleToast} />}

            {/* ✅ Modal Popup for Full Details */}
            {modalActive && selectedEntry && (
                <Modal
                    open={modalActive}
                    onClose={toggleModal}
                    title={`History Details (ID: ${selectedEntry.id})`}
                    primaryAction={{ content: "Close", onAction: toggleModal }}
                >
                    <Modal.Section>
                        {selectedEntry.logs.length > 0 ? (
                            <>
                                <Text as="h3">Log Entries:</Text>

                                <IndexTable
                                    resourceName={{ singular: "log", plural: "logs" }}
                                    itemCount={selectedEntry.logs.length}
                                    headings={[
                                        { title: "SKU" },
                                        { title: "Stock" },
                                        { title: "Message" },
                                        { title: "Status" },
                                        { title: "Timestamp" },
                                    ]}
                                >
                                    {selectedEntry.logs.map((log) => (
                                        <IndexTable.Row id={log.id} key={log.id}>
                                            <IndexTable.Cell>{log.sku}</IndexTable.Cell>
                                            <IndexTable.Cell>{log.stock || "0"}</IndexTable.Cell>
                                            <IndexTable.Cell>{log.message}</IndexTable.Cell>
                                            <IndexTable.Cell>{log.status}</IndexTable.Cell>
                                            <IndexTable.Cell>{new Date(log.timestamp).toLocaleString()}</IndexTable.Cell>
                                        </IndexTable.Row>
                                    ))}
                                </IndexTable>
                            </>
                        ) : (
                            <Text>No logs found for this entry.</Text>
                        )}
                    </Modal.Section>
                </Modal>
            )}
        </Frame>
    );
}
