import {
  Page, Layout, Text, Card, Button, BlockStack, Box, Collapsible, List, Link, InlineStack,
} from "@shopify/polaris";
import { TitleBar, useAppBridge } from "@shopify/app-bridge-react";
import { useState } from "react";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }) => {
  await authenticate.admin(request);

  return null;
};


export default function Index() {
  const faqs = [
    {
      question: "How does the sync process work?",
      answer: "Our sync app connects with your data sources and updates your information in real-time or at scheduled intervals. You can manually trigger a sync, enable automatic syncing, or set up custom API syncs for dynamic data management."
    },
    {
      question: "Can I schedule automatic syncs?",
      answer: "Yes! Our app allows you to configure scheduled syncs at specific intervals. You can set up automatic updates to ensure your data stays current without manual intervention."
    },
    {
      question: "What should I do if my sync fails?",
      answer: "If a sync fails, check the Sync Logs section for error messages and details. Common issues include API authentication failures, incorrect data formats, or server timeouts. If the problem persists, reach out to our support team for assistance."
    },
    {
      question: "How do I configure a custom API sync?",
      answer: "Go to Dynamic API Settings and enter your API credentials, endpoint URLs, and required parameters. Once configured, you can trigger custom syncs on demand or schedule them based on your needs."
    },
    {
      question: "Will my data be overwritten during syncing?",
      answer: "No, your data is updated based on predefined rules. You can configure whether to append new records, update existing ones, or replace outdated entries to ensure data consistency without accidental loss."
    }
  ];

  const [openIndexes, setOpenIndexes] = useState([]);

  const toggleFAQ = (index) => {
    setOpenIndexes((prev) =>
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };



  return (
    <Page>
      <TitleBar title="Dashboard">
        {/* <Button variant="primary" onClick={generateProduct}>
          Generate a product
        </Button> */}
      </TitleBar>

      <BlockStack gap="500">
        <Layout>
          {/* Welcome & Info Section */}
          <Layout.Section>
            <Card>
              <BlockStack gap="500">
                <BlockStack gap="200">
                  <Text as="h1" variant="headingMd">
                    Hi 👋 Welcome to Your Product Sync App!
                  </Text>
                  <Text variant="bodyMd" as="p">
                    Easily sync and manage your product stock in just a few clicks! Use manual SKU entry, bulk CSV/XML uploads, or vendor API to keep your inventory up to date.
                  </Text>
                </BlockStack>

                {/* Sync Options Section */}
                <BlockStack gap="200">
                  <Text as="h3" variant="headingMd">
                    🔄 Get Started with Product Sync
                  </Text>
                  <Text variant="bodyMd">
                    Choose a sync method below to update your store’s inventory effortlessly.
                  </Text>
                </BlockStack>

                <InlineStack gap="300">
                  <Button >
                    <Link to="/app/additional">📝 Manual Sync (Single SKU Entry)</Link>

                  </Button>
                  <Text variant="bodyMd" as="p">
                    Manually update stock for specific products using SKU.
                  </Text>
                </InlineStack>

                <InlineStack gap="300">
                  <Button to="/app/bulk-sync">
                    📂 Bulk Sync (CSV/XML Upload)
                  </Button>
                  <Text variant="bodyMd" as="p">
                    Upload a CSV or XML file with SKU & stock quantity to update multiple products at once.
                  </Text>
                </InlineStack>

                <InlineStack gap="300">
                  <Button >
                    <Link to="/app/custom-api-sync"> 🔗 Dynamic Sync (API Integration)</Link>

                  </Button>
                  <Text variant="bodyMd" as="p">
                    Connect with your vendor’s API for real-time stock updates.
                  </Text>
                </InlineStack>
              </BlockStack>
            </Card>
          </Layout.Section>

          {/* Sync History Section */}
          <Layout.Section>
            {faqs.map((faq, index) => (
              <Card key={index} sectioned>
                <Button
                  fullWidth
                  onClick={() => toggleFAQ(index)}
                  ariaExpanded={openIndexes.includes(index)}
                  ariaControls={`faq-${index}`}
                  style={{ display: 'flex', justifyContent: 'flex-start' }} // ✅ Ensures text aligns left
                >
                  <Text as="h3" variant="headingMd" style={{ textAlign: 'left', width: '100%' }}>
                    {faq.question}
                  </Text>
                </Button>

                <Collapsible open={openIndexes.includes(index)} id={`faq-${index}`}>
                  <Text variant="bodyMd" as="p" style={{ marginTop: '30px', textAlign: 'left' }}>
                    {faq.answer}
                  </Text>
                </Collapsible>
              </Card>
            ))}
          </Layout.Section>


        </Layout>
      </BlockStack>
    </Page>
  );
}
