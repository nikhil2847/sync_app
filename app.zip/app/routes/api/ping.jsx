// /routes/api/ping.jsx (Remix format example)

export const loader = async ({ request }) => {
    return new Response(JSON.stringify({ message: "pong" }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
    });
};
