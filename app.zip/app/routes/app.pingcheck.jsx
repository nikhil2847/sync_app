
// import { useOutletContext } from "@remix-run/react";
// // Shared session token cache


// export default function PingCheck() {
//     // const [sessionToken, setSessionToken] = useState(sessionTokenCache);
//     const { jwtToken } = useOutletContext();
//     // useEffect(() => {
//     //     if (typeof window !== "undefined") {
//     //         const urlParams = new URLSearchParams(window.location.search);
//     //         const apiKey = "YOUR_SHOPIFY_API_KEY"; // Replace with your actual API key
//     //         const host = urlParams.get("host");

//     //         if (!host) {
//     //             console.error("Host parameter is missing in the URL.");
//     //             return;
//     //         }

//     //         // Initialize Shopify App Bridge
//     //         const app = createApp({
//     //             apiKey: apiKey,
//     //             host: host,
//     //             forceRedirect: true,
//     //         });

//     //         // Fetch the session token
//     //         const fetchToken = async () => {
//     //             try {
//     //                 const token = await getSessionToken(app);
//     //                 sessionTokenCache = token; // Store the token in the cache
//     //                 setSessionToken(token);
//     //                 console.log("Session Token:", token);
//     //             } catch (error) {
//     //                 console.error("Error fetching session token:", error);
//     //             }
//     //         };

//     //         // Use the cached token if available, otherwise fetch a new one
//     //         if (sessionTokenCache) {
//     //             console.log("Using cached session token:", sessionTokenCache);
//     //             setSessionToken(sessionTokenCache);
//     //         } else {
//     //             fetchToken();
//     //         }

//     //         // Refresh the token periodically
//     //         const interval = setInterval(fetchToken, 50000);
//     //         return () => clearInterval(interval);
//     //     }
//     // }, []);

//     return (
//         <div>
//             <h1>Ping Check</h1>
//             <p>Session Token: {jwtToken || "Fetching..."}</p>
//         </div>
//     );
// }