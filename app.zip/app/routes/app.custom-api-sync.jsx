import { useEffect, useState } from "react";
import { json } from "@remix-run/node";
import { useFetcher } from "@remix-run/react";
import { Page, Layout, Text, Card, Button, BlockStack, TextField, Modal, ProgressBar, Pagination, Box, Icon } from "@shopify/polaris";
import { TitleBar, useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { useOutletContext } from "@remix-run/react";
import { useLoaderData } from "@remix-run/react";
import db from "../db.server";
export const loader = async ({ request }) => {
  try {
    // Authenticate adminnp
    await authenticate.admin(request);

    // Fetch settings from the database
    const setting = await db.setting.findFirst();
    if (!setting) {
      throw new Error("No settings found in the database.1232");
    }
    // Return the settings as JSON
    return json(setting);
  } catch (error) {
    console.error("Loader Error:", error);
    throw new Error("Failed to load setting.");
  }
};

// Query and Mutation to get and Post

export const action = async ({ request }) => {


  const { admin } = await authenticate.admin(request);
  const formData = new URLSearchParams(await request.text());
  const stockQuantity = Number(formData.get("stockQuantity")) || 0;
  // console.log("request---", stockQuantity);
  const sku = formData.get("sku");

  const sessionToken = formData.get("sessionToken");
  if (!sessionToken) {
    throw new Response("Unauthorized", { status: 401 });
  }
  // Step 1: Query to get all product variants by SKU
  const productQuery = await admin.graphql(
    `#graphql
     query GetProductQuantityBySKU($sku: String) {
       products(first: 250, query: $sku) {
         edges {
           node {
             id
             title
             variants(first: 250) {
               edges {
                 node {
                   id
                   sku
                   inventoryQuantity
                 }
               }
             }
           }
         }
       }
     }`,
    {
      variables: { sku },
      headers: {
        Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
      },
    }
  );

  const productQueryResponse = await productQuery.json();
  // let successCount = 0;
  // let failureCount = 0;
  // const successItems = [];
  // const failureItems = [];
  // Check if the product exists and has variants
  if (!productQueryResponse.data || !productQueryResponse.data.products.edges.length) {
    console.error(`No product found for SKU ${sku}.`);
    // failureCount++;
    // failureItems.push({ sku });
    return json({ errors: [{ field: `${sku}`, message: "No product found for this SKU." }] });
  }

  // Step 2: Loop through all the variants and update only the one with the matching SKU
  const productVariants = productQueryResponse.data.products.edges[0].node.variants.edges;

  // Only proceed if a variant with the matching SKU is found
  const matchingVariant = productVariants.find(variant => variant.node.sku === sku);
  if (!matchingVariant) {
    console.error(`Failed to sync: No variant found with the specified SKU ${sku}`);
    // failureCount++;
    // failureItems.push({ sku });
    return json({ errors: [{ field: `${sku}`, message: "No variant found with the specified SKU." }] });

  }
  // successCount++;
  // successItems.push({ sku });
  // setSyncSummary({ successCount, failureCount, successItems, failureItems });
  // setIsSummaryPopupOpen(true);
  console.log(`Successfully found variant for SKU ${sku}. Proceeding to update inventory.`);
  const inventoryQuantity = matchingVariant.node.inventoryQuantity;
  const variantId = matchingVariant.node.id;


  // Step 3: Fetch inventory item and location data for the matching variant
  const productVariantQuery = await admin.graphql(
    `#graphql
     query getProductVariantById($variantId: ID!) {
       productVariant(id: $variantId) {
         id
         sku
         inventoryItem {
           id
           inventoryLevels(first: 250) {
             edges {
               node {
                 id
                 location {
                   id
                   name
                 }
               }
             }
           }
         }
       }
     }`,
    {
      variables: { variantId },
      headers: {
        Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
      },
    }
  );

  const productVariantResponse = await productVariantQuery.json();
  const inventoryData = productVariantResponse.data.productVariant.inventoryItem.inventoryLevels.edges;

  if (inventoryData && inventoryData.length > 0) {
    const inventoryItemId = productVariantResponse.data.productVariant.inventoryItem.id;
    const locationId = inventoryData[0].node.location.id;

    // Step 4: Adjust stock for the matching variant
    const input = {
      name: "available",
      reason: "correction",
      referenceDocumentUri: "logistics://some.warehouse/take/2023-01-23T13:14:15Z",
      quantities: [
        {
          inventoryItemId: inventoryItemId,
          locationId: locationId,
          quantity: stockQuantity,
          compareQuantity: inventoryQuantity, // Use the variant's current inventory quantity
        },
      ],
    };

    const response = await admin.graphql(
      `#graphql
      mutation inventorySetQuantities($input: InventorySetQuantitiesInput!) {
        inventorySetQuantities(input: $input) {
          inventoryAdjustmentGroup {
            reason
            referenceDocumentUri
            changes {
              name
              delta
              quantityAfterChange
            }
          }
          userErrors {
            code
            field
            message
          }
        }
      }`,
      {
        variables: { input },
        headers: {
          Authorization: `Bearer ${sessionToken}`, // Pass the sessionToken here
        },
      }
    );

    const responseJson = await response.json();

    if (responseJson.errors || responseJson.data.inventorySetQuantities.userErrors.length > 0) {
      return json({ errors: responseJson.errors || responseJson.data.inventorySetQuantities.userErrors });

    }
  }

  return json({ success: true, sku, sessionToken, stockQuantity, message: "Stock adjusted successfully." });




};

// Query and Mutation to get and Post End
// let sessionTokenCache = null;

export default function Index() {

  const setting = useLoaderData();
  const { sessionToken } = useOutletContext();
  const fetcher = useFetcher();
  const shopify = useAppBridge();
  // const prisma = new PrismaClient();
  const [progress, setProgress] = useState(0); // Progress state
  const [apiProgress, setApiProgress] = useState(0); // API progress state
  const [syncSummary, setSyncSummary] = useState({
    successCount: 0,
    failureCount: 0,
    successItems: [],
    failureItems: [],
  });
  const [isSummaryPopupOpen, setIsSummaryPopupOpen] = useState(false);
  const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [apiData, setApiData] = useState([]); // State for API data
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10; //
  const totalPages = Math.ceil(apiData.length / itemsPerPage);



  // new code --- 

  console.log("session token Custom-APi", sessionToken)
  //Stock Sync from input

  const generateSessionId = () => {
    return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  const [sessionId, setSessionId] = useState("");

  // For the logs

  useEffect(() => {
    if (typeof window !== "undefined") {
      sessionStorage.removeItem("sessionId");  // ✅ Always remove old session on reload
      const newSessionId = generateSessionId();
      sessionStorage.setItem("sessionId", newSessionId);
      setSessionId(newSessionId);
      console.log("New sessionId generated:", newSessionId);
    }
  }, []);
  // For the logs


  //  For the Response in popup and save logs history
  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      console.log("Fetcher Data:", fetcher.data);
      const successItems = [];
      const failureItems = [];

      const { success, sku, stockQuantity, message, errors } = fetcher.data;

      if (success === true && sku && stockQuantity !== undefined) {
        setSyncSummary((prevState) => ({
          ...prevState,
          successCount: prevState.successCount + 1,
          successItems: [...prevState.successItems, { sku, stockQuantity, message }],
        }));

        successItems.push({
          sku,
          stock: stockQuantity,
          message: "Stock updated",
          status: "Success",
        });

        let logsToSave = [{ sku, stock: stockQuantity, message: "Stock updated", status: "Success" }];
        logsToSave = logsToSave.filter(log => log.sku && log.stock !== undefined);

        if (logsToSave.length > 0 && sessionId) { // ✅ Ensure sessionId is set
          fetcher.submit(
            {
              syncType: "Product Sync",
              sessionId: sessionId,
              sessionToken, // ✅ Use state sessionId
              logs: JSON.stringify(logsToSave)
            },
            {
              method: "POST", action: "/app/synclogsapi"
            }
          );
        }

        shopify.toast.show(`Stock adjusted successfully for SKU: ${sku}`);
      } else if (errors && Array.isArray(errors) && errors.length > 0) {
        const errorDetails = errors[0];
        const errorSku = errorDetails.field;

        if (errorSku) {
          setSyncSummary(prevState => ({
            ...prevState,
            failureCount: prevState.failureCount + 1,
            failureItems: [...prevState.failureItems, { sku: errorSku, message: errorDetails.message }],
          }));

          console.log("Failure:", fetcher.data.errors);
          failureItems.push({
            sku: errorSku,
            message: errorDetails.message,
            status: "Failed",
          });

          shopify.toast.show(`SKU Not Found: ${errorSku}`);

          let logsToSave = [{ sku: errorSku, stock: stockQuantity ?? "N/A", message: errorDetails.message, status: "Failed" }];
          logsToSave = logsToSave.filter(log => log.sku && log.stock !== undefined);

          if (logsToSave.length > 0 && sessionId) {  // ✅ Ensure sessionId exists
            fetcher.submit(
              {
                syncType: "Product Sync",
                sessionId: sessionId,
                sessionToken,
                logs: JSON.stringify(logsToSave)
              },
              {
                method: "POST", action: "/app/synclogsapi"
              }
            );
          }
        }
      }
    }
  }, [fetcher.state, fetcher.data, sessionId]);
  //  For the Response in popup and save logs history
  useEffect(() => {
    // startAutoSync();
    if (fetcher.data?.inventoryAdjustment) {
      // fetchVendorData();
      fetchVendorData2();
      // shopify.toast.show("Stock adjusted successfully");
    }
  },
    [fetcher.data?.inventoryAdjustment, shopify]);


  const fetchVendorData2 = async () => {
    setProgress(0);
    setApiData([]);
    setModalMessage("Fetching data...");
    setIsProgressModalOpen(true);

    try {
      const settingsResponse = setting;
      console.log("Loader Data3:", settingsResponse);

      if (!settingsResponse) {
        throw new Error("No settings data found.");
      }

      const { apiEndpoint, format, SKU, Stock } = settingsResponse;
      const apiEndpointmain = `${apiEndpoint}`;
      if (!apiEndpointmain || !format || !SKU || !Stock) {
        throw new Error("Settings data is incomplete.");
      }

      // Allow both CSV and TXT formats
      if (!["csv", "txt"].includes(format.toLowerCase())) {
        throw new Error("Unsupported format. Only CSV and TXT are supported.");
      }

      const apiUrl = `https://cors-proxy-test.rjdiazmiami.workers.dev/?api=${apiEndpoint}`;

      console.log("testshop", apiUrl);
      const response = await fetch(apiUrl, {
        method: "GET",
        headers: {
          'Accept': format.toLowerCase() === "csv" ? "text/csv" : "text/plain",
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch data from ${apiUrl}`);
      }

      const rawData = await response.text();
      const allApiData = [];
      console.log("response---", rawData);

      const rows = rawData.split("\n").map(row => row.trim()).filter(row => row); // Remove empty rows

      if (rows.length === 0) {
        throw new Error("No data found in the response.");
      }

      // Detect delimiter based on the first row (header)
      let delimiter = ",";
      if (rows[0].includes("|")) {
        delimiter = "|";
      } else if (rows[0].includes("\t")) {
        delimiter = "\t";
      } else if (rows[0].includes(" ")) {
        delimiter = " ";
      }

      console.log("Detected delimiter:", delimiter);

      // Extract header
      const headers = rows[0].split(delimiter).map(header => header.trim());

      if (!headers.includes(SKU) || !headers.includes(Stock)) {
        throw new Error("Invalid format: SKU or Stock column missing.");
      }

      // Process each row (skip header)
      rows.slice(1).forEach((row) => {
        if (!row.trim()) return; // Skip empty rows

        const columns = row.split(delimiter).map(col => col.trim());
        const sku = columns[headers.indexOf(SKU)];
        const stock = parseInt(columns[headers.indexOf(Stock)], 10);

        if (sku && !isNaN(stock)) {
          allApiData.push({ sku, stock });
        }
      });

      setApiData(allApiData);
      await syncStockFromAPI(allApiData);

    } catch (error) {
      console.error("Error fetching API data:", error);
      setModalMessage("Failed to fetch API data.");
    } finally {
      setTimeout(() => setIsProgressModalOpen(false), 100);
    }
  };

  const syncStockFromAPI = async (apiData) => {
    const totalProducts = apiData.length;
    let completedSyncs = 0;
    const delayInterval = 100; // Set time interval in milliseconds (e.g., 1000ms = 1 second)
    setModalMessage("Synching vendor data...");
    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    // console.log("API data:", apiData);
    for (const product of apiData) {
      const { sku, stock } = product;
      console.log("Product data:", sku, stock);

      if (sku && !isNaN(stock)) {
        try {
          // console.log(`Syncing SKU: ${sku}, Stock: ${stock}`);
          fetcher.submit({ stockQuantity: stock, sku, sessionToken }, {
            method: "POST",

          });


          // Wait for fetcher to process the response
          await new Promise(async (resolve) => {
            // Wait until fetcher.data is populated or timeout occurs
            const startTime = Date.now();
            const timeout = 3000; // Set a timeout limit (e.g., 5 seconds)

            while (true) {


              // Check for timeout after checking the response status
              if (Date.now() - startTime > timeout) {
                // console.error(`Timeout waiting for response for SKU: ${sku}`);
                // failureCount++;
                // failureItems.push({ sku, stockQuantity });
                shopify.toast.show(`SKU Not Found: ${sku}`);
                resolve(); // Resolve on timeout to prevent infinite loop
                break;
              }


              // Delay for 100ms before checking again
              await new Promise((res) => setTimeout(res, 100));
            }
          });

        } catch {
          // failureCount++;
          // failureItems.push({ sku, stock });
        }

        completedSyncs++;
        const progressPercentage = (completedSyncs / totalProducts) * 100;
        setApiProgress(progressPercentage);
        await delay(delayInterval);
      } else {
        // failureCount++;
        // failureItems.push({ sku, stock });
      }
    }

    // setSyncSummary({ successCount, failureCount, successItems, failureItems });
    setIsSummaryPopupOpen(true);
  };


  const PaginatedTable = ({ apiData }) => {
    const itemsPerPage = 10; // Number of items to show per page
    const [currentPage, setCurrentPage] = useState(1);

    const totalItems = apiData.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Calculate the data for the current page
    const currentPageData = apiData.slice(
      (currentPage - 1) * itemsPerPage,
      currentPage * itemsPerPage
    );

    const handlePrevious = () => {
      if (currentPage > 1) {
        setCurrentPage(currentPage - 1);
      }
    };

    const handleNext = () => {
      if (currentPage < totalPages) {
        setCurrentPage(currentPage + 1);
      }
    };
  }


  const paginatedData = apiData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Handle page change
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };


  return (
    <Page>
      <TitleBar title="Stock Adjustment" />

      <BlockStack gap="500">
        {/* Update Stock by API Section */}
        <Layout>
          <Layout.Section>
            <Card>
              <Card sectioned>
                <Text as="h2" variant="headingMd">
                  Update Stock by API
                </Text>
                <Text as="p" tone="subdued">
                  Fetch the latest vendor stock data and update your inventory in real-time.
                </Text>
                <br />
                <Button onClick={fetchVendorData2} >
                  Fetch Custom Vendor Data
                </Button>
              </Card>
            </Card>
          </Layout.Section>

          <Layout.Section variant="oneThird">
            <BlockStack gap="200">
              <Button onClick={() => setIsProgressModalOpen(true)}>View Progress</Button>
              <Button onClick={() => setIsSummaryPopupOpen(true)}>View Sync Summary</Button>
            </BlockStack>
          </Layout.Section>
        </Layout>

        {/* API Response Section */}
        <Layout>
          <Layout.Section>
            <Card title="Fetched API Data" sectioned>
              <Text as="h2" variant="headingMd">
                Response From API 🎉
              </Text>
              {paginatedData.length > 0 ? (
                <BlockStack>
                  {paginatedData.map((item, index) => (
                    <Text key={index}>{`SKU: ${item.sku}, Stock: ${item.stock}`}</Text>
                  ))}
                </BlockStack>
              ) : (
                <Text tone="subdued">No data fetched yet.</Text>
              )}

              {/* Pagination Controls */}
              {totalPages > 1 && (
                <Box paddingBlockStart="200">
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <Button disabled={currentPage === 1} onClick={() => handlePageChange(currentPage - 1)} >
                      Previous
                    </Button>
                    <Text>{`Page ${currentPage} of ${totalPages}`}</Text>
                    <Button disabled={currentPage === totalPages} onClick={() => handlePageChange(currentPage + 1)} >
                      Next
                    </Button>
                  </div>
                </Box>
              )}
            </Card>
          </Layout.Section>
        </Layout>

        {/* Progress Modal */}
        <Modal
          open={isProgressModalOpen}
          onClose={() => setIsProgressModalOpen(false)}
          title="Stock Sync Progress"
          primaryAction={{ content: "Close", onAction: () => setIsProgressModalOpen(false) }}
        >
          <Modal.Section>
            <ProgressBar progress={progress || apiProgress} />
          </Modal.Section>
        </Modal>

        {/* Sync Summary Modal */}
        <Modal
          open={isSummaryPopupOpen}
          onClose={() => setIsSummaryPopupOpen(false)}
          title="Sync Summary"
          primaryAction={{ content: "Close", onAction: () => setIsSummaryPopupOpen(false) }}
        >
          <Modal.Section>
            <Text as="h3">Sync Results:</Text>
            <Box padding="100">
              <Text tone="success">{`✔️ Successfully Synced: ${syncSummary.successCount}`}</Text>
              <Text tone="critical">{`❌ Failed: ${syncSummary.failureCount}`}</Text>
            </Box>

            <Text as="h3">Synced Products:</Text>
            {syncSummary.successItems.length > 0 ? (
              <BlockStack>
                {syncSummary.successItems.map((item, index) => (
                  <Text key={index}>{`SKU: ${item.sku}, Stock: ${item.stockQuantity}`}</Text>
                ))}
              </BlockStack>
            ) : (
              <Text tone="subdued">No successful syncs.</Text>
            )}

            <Text as="h3">Failed Products:</Text>
            {syncSummary.failureItems.length > 0 ? (
              <BlockStack>
                {syncSummary.failureItems.map((item, index) => (
                  <Text key={index}>{`SKU: ${item.sku}, Message: ${item.message}`}</Text>
                ))}
              </BlockStack>
            ) : (
              <Text tone="subdued">No failed syncs.</Text>
            )}
          </Modal.Section>
        </Modal>
      </BlockStack>
    </Page>
  );
}
