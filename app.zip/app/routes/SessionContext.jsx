import React, { createContext, useContext, useState, useEffect } from "react";
import createApp from "@shopify/app-bridge";
import { getSessionToken } from "@shopify/app-bridge-utils";

const SessionContext = createContext();

export const SessionProvider = ({ apiKey, host, children }) => {
    const [sessionToken, setSessionToken] = useState(null);

    useEffect(() => {
        if (typeof window !== "undefined" && host) {
            const app = createApp({
                apiKey,
                host,
                forceRedirect: true,
            });

            const fetchToken = async () => {
                try {
                    const token = await getSessionToken(app);
                    setSessionToken(token);
                } catch (error) {
                    console.error("Error fetching session token:", error);
                }
            };

            fetchToken();

            // Refresh the token periodically
            const interval = setInterval(fetchToken, 50000);
            return () => clearInterval(interval);
        }
    }, [apiKey, host]);

    return (
        <SessionContext.Provider value={{ sessionToken, setSessionToken }}>
            {children}
        </SessionContext.Provider>
    );
};

export const useSession = () => useContext(SessionContext);